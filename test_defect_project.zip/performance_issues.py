
import time
import threading
import requests

def inefficient_loop():
    # 低效的循环
    result = []
    for i in range(10000):
        result.append(i * 2)  # 应该使用列表推导式
    return result

def blocking_operations():
    # 阻塞操作
    time.sleep(10)  # 长时间阻塞
    return "完成"

def memory_leak():
    # 内存泄漏示例
    data = []
    for i in range(1000000):
        data.append("x" * 1000)  # 大量内存占用
    return data

def inefficient_string_concatenation():
    # 低效的字符串拼接
    result = ""
    for i in range(1000):
        result += str(i)  # 应该使用join
    return result

def synchronous_requests():
    # 同步请求，应该使用异步
    urls = ["http://httpbin.org/delay/1"] * 5
    results = []
    for url in urls:
        response = requests.get(url)
        results.append(response.json())
    return results

def infinite_recursion():
    # 无限递归
    return infinite_recursion()

if __name__ == "__main__":
    print("性能问题测试")
    # inefficient_loop()
    # blocking_operations()
    # inefficient_string_concatenation()
