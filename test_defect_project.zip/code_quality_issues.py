
import os, sys, json, time, random, math, datetime, collections, itertools, functools

def bad_function_name():  # 函数名不够描述性
    a = 1  # 变量名不够描述性
    b = 2
    c = a + b
    return c

def long_function():
    # 函数过长，应该拆分
    data = []
    for i in range(100):
        if i % 2 == 0:
            if i % 3 == 0:
                if i % 5 == 0:
                    data.append(i)
    
    result = []
    for item in data:
        if item > 50:
            result.append(item * 2)
        else:
            result.append(item)
    
    final_result = []
    for item in result:
        if item > 100:
            final_result.append(item)
    
    return final_result

def duplicate_code():
    # 重复代码
    list1 = [1, 2, 3, 4, 5]
    list2 = [6, 7, 8, 9, 10]
    
    # 重复的逻辑
    sum1 = 0
    for item in list1:
        sum1 += item
    
    sum2 = 0
    for item in list2:
        sum2 += item
    
    return sum1 + sum2

def magic_numbers():
    # 魔法数字
    if len(data) > 100:  # 100是什么？
        return True
    elif len(data) < 50:  # 50是什么？
        return False
    else:
        return len(data) * 1.5  # 1.5是什么？

def unused_imports():
    # 未使用的导入
    import unused_module
    import another_unused_module
    
    return "只使用了这个字符串"

def inconsistent_formatting():
    # 不一致的格式
    x=1+2+3
    y = 4 + 5 + 6
    z=7+8+9
    
    if x>y:
        print("x大于y")
    elif x < y:
        print("x小于y")
    else:
        print("x等于y")

def no_docstring():
    # 没有文档字符串
    return "这个函数没有文档说明"

def too_many_parameters(a, b, c, d, e, f, g, h, i, j):
    # 参数过多
    return a + b + c + d + e + f + g + h + i + j

if __name__ == "__main__":
    print("代码质量问题测试")
    bad_function_name()
    long_function()
    duplicate_code()
    magic_numbers()
    unused_imports()
    inconsistent_formatting()
    no_docstring()
    too_many_parameters(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
