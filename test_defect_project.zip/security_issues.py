
import os
import subprocess
import pickle

def unsafe_eval():
    # 使用eval执行用户输入
    user_input = input("请输入表达式: ")
    result = eval(user_input)  # 危险！
    return result

def unsafe_exec():
    # 使用exec执行代码
    code = input("请输入代码: ")
    exec(code)  # 危险！

def unsafe_pickle():
    # 不安全的pickle反序列化
    data = input("请输入pickle数据: ")
    obj = pickle.loads(data.encode())  # 危险！
    return obj

def command_injection():
    # 命令注入漏洞
    filename = input("请输入文件名: ")
    os.system(f"cat {filename}")  # 危险！

def sql_injection_example():
    # SQL注入示例
    user_id = input("请输入用户ID: ")
    query = f"SELECT * FROM users WHERE id = {user_id}"  # 危险！
    return query

if __name__ == "__main__":
    print("这是一个有安全问题的示例文件")
    # unsafe_eval()
    # unsafe_exec()
    # command_injection()
