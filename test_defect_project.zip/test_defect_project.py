
import unittest
import sys
import os

# 添加项目路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

class TestDefectProject(unittest.TestCase):
    """测试有缺陷的项目"""
    
    def test_working_code(self):
        """测试正常代码"""
        from working_code import add_numbers, hello_world
        
        # 测试加法
        self.assertEqual(add_numbers(2, 3), 5)
        
        # 测试Hello World
        result = hello_world()
        self.assertEqual(result, "Hello, World!")
    
    def test_syntax_errors(self):
        """测试语法错误（应该失败）"""
        try:
            import syntax_errors
            self.fail("语法错误文件应该无法导入")
        except SyntaxError:
            pass  # 预期的语法错误
    
    def test_security_issues(self):
        """测试安全问题"""
        try:
            import security_issues
            # 这里可以添加安全检查
            pass
        except Exception as e:
            print(f"安全检查捕获到问题: {e}")

if __name__ == "__main__":
    unittest.main()
