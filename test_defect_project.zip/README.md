# 测试项目 - 有缺陷的代码

这是一个专门用于测试动态检测功能的有缺陷项目。

## 包含的缺陷类型

### 1. 语法错误 (syntax_errors.py)
- 缺少冒号
- 未定义的变量
- 缩进错误

### 2. 安全问题 (security_issues.py)
- eval() 使用
- exec() 使用
- pickle 反序列化
- 命令注入
- SQL注入

### 3. 性能问题 (performance_issues.py)
- 低效循环
- 阻塞操作
- 内存泄漏
- 低效字符串拼接
- 同步请求

### 4. 逻辑错误 (logic_errors.py)
- 除零错误
- 索引越界
- 类型错误
- 键错误
- 属性错误

### 5. 代码质量问题 (code_quality_issues.py)
- 函数名不够描述性
- 函数过长
- 重复代码
- 魔法数字
- 未使用的导入
- 不一致的格式

### 6. 正常代码 (working_code.py)
- 正常的Python代码示例

## 使用方法

1. 解压项目
2. 安装依赖: `pip install -r requirements.txt`
3. 运行测试: `python working_code.py`

## 注意事项

⚠️ 这个项目包含有意的缺陷，仅用于测试目的，不要在生产环境中使用。
