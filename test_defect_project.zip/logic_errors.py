
def divide_by_zero():
    # 除零错误
    a = 10
    b = 0
    return a / b

def index_out_of_range():
    # 索引越界
    my_list = [1, 2, 3]
    return my_list[10]

def type_error():
    # 类型错误
    number = 42
    text = "hello"
    return number + text

def key_error():
    # 键错误
    my_dict = {"a": 1, "b": 2}
    return my_dict["c"]

def attribute_error():
    # 属性错误
    obj = None
    return obj.some_attribute

def value_error():
    # 值错误
    return int("not_a_number")

def file_not_found():
    # 文件不存在
    with open("nonexistent_file.txt", "r") as f:
        return f.read()

def network_error():
    # 网络错误
    import requests
    return requests.get("http://nonexistent-domain.com")

if __name__ == "__main__":
    print("逻辑错误测试")
    try:
        # divide_by_zero()
        # index_out_of_range()
        # type_error()
        # key_error()
        # attribute_error()
        # value_error()
        # file_not_found()
        pass
    except Exception as e:
        print(f"捕获到错误: {e}")
