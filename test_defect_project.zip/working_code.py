
def hello_world():
    """正常的Hello World函数"""
    print("Hello, World!")
    return "Hello, World!"

def add_numbers(a, b):
    """正常的加法函数"""
    return a + b

def main():
    """主函数"""
    result = hello_world()
    print(f"Result: {result}")
    
    # 测试加法
    sum_result = add_numbers(5, 3)
    print(f"5 + 3 = {sum_result}")
    
    # 测试列表操作
    numbers = [1, 2, 3, 4, 5]
    doubled = [x * 2 for x in numbers]
    print(f"Doubled numbers: {doubled}")
    
    # 测试字典操作
    person = {"name": "Alice", "age": 30}
    print(f"Person: {person}")

if __name__ == "__main__":
    main()
