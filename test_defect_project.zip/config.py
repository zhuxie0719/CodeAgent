
# 测试项目配置文件
PROJECT_NAME = "Defect Test Project"
VERSION = "1.0.0"
DEBUG = True

# 数据库配置
DATABASE_URL = "sqlite:///test.db"
DATABASE_POOL_SIZE = 10

# API配置
API_HOST = "localhost"
API_PORT = 8000
API_TIMEOUT = 30

# 日志配置
LOG_LEVEL = "INFO"
LOG_FILE = "app.log"
