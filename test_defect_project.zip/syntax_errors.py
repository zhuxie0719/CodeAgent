
def broken_function():
    # 缺少冒号
    if True
        print("这行代码有语法错误")
    
    # 未定义的变量
    print(undefined_variable)
    
    # 缩进错误
    return "Hello World"
        print("这行缩进错误")

# 调用有问题的函数
broken_function()
