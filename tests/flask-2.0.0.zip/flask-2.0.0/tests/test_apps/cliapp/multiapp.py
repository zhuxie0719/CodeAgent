from flask import Flask

app1 = Flask("app1")
app2 = Flask("app2")
