To report a security vulnerability to pandas, please go to https://tidelift.com/security and see the instructions there.
