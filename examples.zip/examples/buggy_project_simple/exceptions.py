try:
    x = 1 / 0
except Exception as e:  # broad_exception: medium
    pass  # empty_except: medium


