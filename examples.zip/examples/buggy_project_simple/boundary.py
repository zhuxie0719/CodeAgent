def loop_boundary(arr):
    # 循环边界越界
    for i in range(0, len(arr) + 1):  # loop_boundary: medium
        print(arr[i])


