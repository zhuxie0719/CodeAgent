Sample Python Project
=====================

Structure:
- src/calculator.py
- tests/test_calculator.py (contains an intentional failing test)

How to run tests locally (if you have pytest):
1) pip install pytest
2) python -m pytest -v


